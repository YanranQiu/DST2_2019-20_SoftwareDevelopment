package dao;

import java.util.List;

public interface IAnnovardao {
    public void save(int sampleId, String content);
    public List<String> getRefGenes(int sampleId);
}
