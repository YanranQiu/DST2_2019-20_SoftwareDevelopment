package service;

import java.util.List;

public interface IAnnovarService {
    public void save(int sampleId, String content);
    public List<String> getRefGenes(int sampleId);
}
