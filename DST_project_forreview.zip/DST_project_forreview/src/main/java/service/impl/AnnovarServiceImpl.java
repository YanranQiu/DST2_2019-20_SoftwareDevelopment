package service.impl;

import dao.IAnnovardao;
import dao.IDrugdao;
import dao.impl.AnnovardaoImpl;
import dao.impl.DrugdaoImpl;

import java.util.List;

public class AnnovarServiceImpl {
    private IAnnovardao dao = new AnnovardaoImpl();
    public void save(int sampleId, String content){
        dao.save(sampleId,content);
    };
    public List<String> getRefGenes(int sampleId){
        return dao.getRefGenes(sampleId);
    };
}
