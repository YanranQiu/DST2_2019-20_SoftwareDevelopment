package web.servlet;

import filter.UserFilter;
import service.impl.AnnovarServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet("/annovarresult")
public class AnnovarResultServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        AnnovarServiceImpl annovarservice = new AnnovarServiceImpl();
        HttpSession session = request.getSession();
        String content = (String) session.getAttribute("content");
        System.out.println(content);
        if (content != null){
            annovarservice.save(1,content);
            List<String> refGenes = annovarservice.getRefGenes(1);
            request.setAttribute("refgenes",refGenes);
            request.getRequestDispatcher("jsp/result.jsp").forward(request,response);
        }else {
            System.out.println("fucking error");
        }

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        this.doPost(request, response);
    }
}
