package service.impl;

import dao.IVEPdao;
import dao.impl.VEPdaoImpl;
import service.IVEPService;

import java.util.List;

public class VEPServiceImpl implements IVEPService {
    private IVEPdao dao = new VEPdaoImpl();
    public void save(String filename, String content){
        dao.save(filename,content);
    };
    public List<String> getSymbol(String filename){ return dao.getSymbol(filename); };
    public List<String> findDrug (String gene) {return dao.findDrug(gene); };
    public boolean exists(String drugID, String drugGene) {return dao.exists(drugID,drugGene); };
}
