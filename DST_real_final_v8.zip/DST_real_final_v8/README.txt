# Precision Medicine Project

This is the repository for DST2 2019-20 semester 2 precision medicine project.

the final version of source code is final_v8 , you can download it and deploy with tomcat 7.

the plugin or software you need: (tomcat 7, maven, mysql)

Annovar_file contains variant_annotation output. 
(actually variant_annotation was completed with VEP, but the output file format of the two software is the same)